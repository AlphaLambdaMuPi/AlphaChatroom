
//
// File:    mismatch2.java
// Purpose: generates a java error mismatch filename/class.
// Author:  pc2@ecs.csus.edu or http://www.ecs.csus.edu/pc2
// Oct 13 1998
//
// $Id: mismatch2.java 1962 2009-11-25 03:42:12Z boudreat $
//

public class MisMatch2 {
    public static void main(String[] args) 
    {
         System.out.println("Hello World.");
    }
}

// eof
